from .fakedata import *

RandomOneName = FakeData.RandomOneName
RandomTwoName = FakeData.RandomTwoName
RandomUSAName = FakeData.RandomUSAName
RandomName = FakeData.RandomName
CheckSex = FakeData.CheckSex
RandomSex = FakeData.RandomSex
RandomEmail = FakeData.RandomEmail
PersonalizedEmail = FakeData.PersonalizedEmail

